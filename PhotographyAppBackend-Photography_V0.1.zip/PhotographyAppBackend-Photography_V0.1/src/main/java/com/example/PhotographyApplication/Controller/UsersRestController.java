package com.example.PhotographyApplication.Controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.PhotographyApplication.Dto.LoginDteailsMessageDto;
import com.example.PhotographyApplication.Dto.ResponseMessageDto;
import com.example.PhotographyApplication.Dto.UserDto;
import com.example.PhotographyApplication.Dto.UserRequestDto;
import com.example.PhotographyApplication.Dto.UsersBookingDto;
import com.example.PhotographyApplication.Dto.UsersBookingResponse;
import com.example.PhotographyApplication.Model.TermsAboutUs;
import com.example.PhotographyApplication.Model.Users;
import com.example.PhotographyApplication.Model.UsersBooking;
import com.example.PhotographyApplication.Repository.UsersRepository;
import com.example.PhotographyApplication.RepositoryImpl.UsersOtpService;
import com.example.PhotographyApplication.RepositoryImpl.UsersRepositoryImpl;
import com.example.PhotographyApplication.Service.UsersBookingService;
import com.example.PhotographyApplication.Service.UsersService;
@RestController
@RequestMapping("/api/users")
public class UsersRestController {

	@Autowired
	private UsersService usersService;

	@Autowired
	private UsersRepositoryImpl usersRepositoryImpl;

	@Autowired
	private UsersRepository usersRepository;

	@Autowired
	private UsersOtpService otpService;

	@Autowired
	private UsersBookingService usersBookingService;

	// -------------------------------------------------------------------------
	// Back-end to users
	// -------------------------------------------------------------------------

	@RequestMapping(value = "/sign-up", method = RequestMethod.POST)
	public ResponseEntity<LoginDteailsMessageDto> registerUser(@RequestBody Users users) {
		// Validation
		if (users == null || users.getPhoneNumber() == null || users.getUserName() == null) {
			LoginDteailsMessageDto validationError = new LoginDteailsMessageDto("Failed", "Invalid user data.", null,
					null, "Validation error", new Date(), false);
			return new ResponseEntity<>(validationError, HttpStatus.OK);
		}

		// Check if the phone number already exists
		boolean phoneNumberExists = usersRepository.existsByPhoneNumber(users.getPhoneNumber());

		if (phoneNumberExists) {
			LoginDteailsMessageDto phoneNumberError = new LoginDteailsMessageDto("Failed",
					"Phone number already exists.", null, null, "Duplicate phone number", new Date(), false);

			return new ResponseEntity<>(phoneNumberError, HttpStatus.OK);

		}

		// Phone number is unique, proceed with registration
		String phoneNumber = users.getPhoneNumber();
		otpService.sendOtp(phoneNumber);
		users.setUserRegDateTime(LocalDate.now());
		usersRepository.save(users);
		LoginDteailsMessageDto successResponse = new LoginDteailsMessageDto("Success", "User successfully registered!",
				users.getUserId(), null, null, new Date(), true);

		return new ResponseEntity<>(successResponse, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/detail", method = RequestMethod.POST)
	public ResponseEntity<?> getUserViewRecords(@RequestBody Map<String, Long> request) {
		Long userId = request.get("userId");
		Users users = usersService.getUsersById(userId);

		if (users != null) {
			// Convert User to UserDto
			UserDto userDto = convertToDto(users);
			// User found, return details
			return ResponseEntity.status(HttpStatus.OK).body(userDto);
		} else {
			ResponseMessageDto responseMessageDto = new ResponseMessageDto("Failure", "User Details Not Found", "",
					new Date(), false);
			return ResponseEntity.status(HttpStatus.OK).body(responseMessageDto);
		}
	}

	private UserDto convertToDto(Users users) {
		UserDto userDto = new UserDto();
		userDto.setUserId(users.getUserId());
		userDto.setUserRegDateTime(users.getUserRegDateTime());
		userDto.setUserName(users.getUserName());
		userDto.setPhoneNumber(users.getPhoneNumber());

		return userDto;
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public ResponseEntity<ResponseMessageDto> updateUsers(@RequestBody Users updatedUser) {

		Long userId = updatedUser.getUserId();
		String phoneNumber = updatedUser.getPhoneNumber();

		// Check if a user with the given phone number already exists
		if (usersService.isPhoneNumberTakenByOtherUser(phoneNumber, userId)) {
			ResponseMessageDto numberExistsMessage = new ResponseMessageDto();
			numberExistsMessage.setStatus("Failed");
			numberExistsMessage.setMessage("Phone number already exists");
			numberExistsMessage.setTimestamp(new Date());
			numberExistsMessage.setVerified(false);

			return new ResponseEntity<>(numberExistsMessage, HttpStatus.OK);
		}

		// Update the user in the database
		Users updatedEntity = usersService.updateUser(userId, updatedUser);

		if (updatedEntity != null) {
			// Successful update
			ResponseMessageDto successMessage = new ResponseMessageDto();
			successMessage.setStatus("Success");
			successMessage.setMessage("User updated successfully");
			successMessage.setTimestamp(new Date());
			successMessage.setVerified(true);

			return new ResponseEntity<>(successMessage, HttpStatus.OK);
		} else {
			// User with the given ID not found
			ResponseMessageDto notFoundMessage = new ResponseMessageDto();
			notFoundMessage.setStatus("Failed");
			notFoundMessage.setMessage("User not found with ID: " + userId);
			notFoundMessage.setTimestamp(new Date());
			notFoundMessage.setVerified(false);

			return new ResponseEntity<>(notFoundMessage, HttpStatus.OK);
		}
	}

	@RequestMapping(value = "/send-otp", method = RequestMethod.POST)
	public ResponseEntity<ResponseMessageDto> sendOtp(@RequestBody UserRequestDto request) {
		String phoneNumber = request.getPhoneNumber();
		String userType = request.getUserType();

		Users users = usersRepository.findByPhoneNumber(phoneNumber);

		if ("new".equals(userType)) {
			if (users == null) {
				otpService.sendOtp(phoneNumber);
				ResponseMessageDto response = new ResponseMessageDto("Success", "OTP sent successfully", null,
						new Date(), true);
				return ResponseEntity.ok(response);
			} else {
				ResponseMessageDto response = new ResponseMessageDto("Failed", "User already exists. Please log in.",
						null, new Date(), false);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		} else {
			if (users != null) {
				otpService.sendOtp(phoneNumber);
				ResponseMessageDto response = new ResponseMessageDto("Success", "OTP sent successfully", null,
						new Date(), true);
				return ResponseEntity.ok(response);
			} else {
				ResponseMessageDto response = new ResponseMessageDto("Failed", "User not found.", null, new Date(),
						false);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		}
	}

	@RequestMapping(value = "/verify-otp", method = RequestMethod.POST)
	public ResponseEntity<LoginDteailsMessageDto> verifyOtp(@RequestBody Users loginRequest) {
		String phoneNumber = loginRequest.getPhoneNumber();
		String userOtpVerification = loginRequest.getUserOtpVerification();

//		// Verify the OTP
//		boolean isOtpVerified = otpService.verifyOtp(phoneNumber, userOtpVerification);
		Users users = usersRepository.findByPhoneNumber(phoneNumber);
//
//		if (isOtpVerified) {

		// Assuming the fixed value you want to compare with is "1234"
		String fixedOtpValue = "1234";

		// Check if the provided OTP matches the fixed value
		if (fixedOtpValue.equals(userOtpVerification)) {
			// If the OTP is verified successfully, return a success response
			LoginDteailsMessageDto response = new LoginDteailsMessageDto("Success", "OTP verified successfully",
					users.getUserId(), null, null, new Date(), true);
			return ResponseEntity.ok(response);
		} else {
			// If the OTP is not verified, return an error response
			LoginDteailsMessageDto response = new LoginDteailsMessageDto("Error", "OTP is not matching", null, null,
					null, new Date(), false);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}
	}

	// -------------------------------------------------------------------------
	// Back-end API to Users Booking Details
	// -------------------------------------------------------------------------

	@RequestMapping(value = "/user-save-booking", method = RequestMethod.POST)
	public ResponseEntity<ResponseMessageDto> addUsersBooking(@RequestBody UsersBookingDto request) {
		ResponseMessageDto responseMessageDto;

		try {

			Users users = usersService.getUsersById(request.getUserId());

			UsersBooking usersBooking = new UsersBooking();
			usersBooking.setUsersBookingRegDate(new Date());
			usersBooking.setUserName(request.getUserName());
			usersBooking.setAddress(request.getAddress());
			usersBooking.setStartTime(request.getStartTime());
			usersBooking.setEndTime(request.getEndTime());
			usersBooking.setPricePerHour(request.getPricePerHour());
			usersBooking.setDuration(request.getDuration());
			usersBooking.setEndSessioOtp(request.getEndSessioOtp());
			usersBooking.setStartSessionOtp(request.getStartSessionOtp());
			usersBooking.setAddress(request.getAddress());
			usersBooking.setStatus(request.getStatus());
			usersBooking.setUsers(users);

			usersBookingService.saveUsersBooking(usersBooking);

			responseMessageDto = new ResponseMessageDto("Success", "User Booking add successfully", "", new Date(),
					true);

			return new ResponseEntity<>(responseMessageDto, HttpStatus.OK);
		} catch (DataIntegrityViolationException ex) {
			responseMessageDto = new ResponseMessageDto("Failure", "User Booking is not add successfully", "",
					new Date(), false);
			return new ResponseEntity<>(responseMessageDto, HttpStatus.OK);
		}
	}

	@RequestMapping(value = "/user-booking-details", method = RequestMethod.POST)
	public ResponseEntity<?> getPhotographerBookingDatailsViewRecords(@RequestBody Map<String, Object> request) {

		Number usersIdNumber = (Number) request.get("userId");
		Long userId = usersIdNumber.longValue(); // Converts to Long

		String bookingType = (String) request.get("bookingType");

		List<UsersBooking> usersBookings = usersBookingService.getUsersByUserId(userId);

		UsersBookingResponse usersBookingResponse = new UsersBookingResponse();
		List<UsersBookingDto> usersBookingDtos = new ArrayList<>();

		for (UsersBooking usersBooking : usersBookings) {
			if (usersBooking.getUsers().getUserId().equals(userId)) {
				UsersBookingDto usersBookingDto = new UsersBookingDto();
				usersBookingDto.setUsersBookingId(usersBooking.getUsersBookingId());
				usersBookingDto.setUserId(userId);
				usersBookingDto.setUsersBookingRegDate(new Date());
				usersBookingDto.setUserName(usersBooking.getUserName());
				usersBookingDto.setAddress(usersBooking.getAddress());
				usersBookingDto.setStartTime(usersBooking.getStartTime());
				usersBookingDto.setEndTime(usersBooking.getEndTime());
				usersBookingDto.setPricePerHour(usersBooking.getPricePerHour());
				usersBookingDto.setDuration(usersBooking.getDuration());
				usersBookingDto.setEndSessioOtp(usersBooking.getEndSessioOtp());
				usersBookingDto.setStartSessionOtp(usersBooking.getStartSessionOtp());
				usersBookingDto.setStatus(usersBooking.getStatus());

				// Check booking type and status
				if (bookingType.equalsIgnoreCase("past") && (usersBooking.getStatus().equalsIgnoreCase("completed")
						|| usersBooking.getStatus().equalsIgnoreCase("cancelled"))) {
					usersBookingDtos.add(usersBookingDto);
				} else if (bookingType.equalsIgnoreCase("ongoing")
						&& (usersBooking.getStatus().equalsIgnoreCase("accepted")
								|| usersBooking.getStatus().equalsIgnoreCase("ongoing"))) {
					usersBookingDtos.add(usersBookingDto);
				}
			}
		}

		if (usersBookingDtos.isEmpty()) {
			usersBookingResponse.setStatus(false);
		} else {
			usersBookingResponse.setStatus(true);
			usersBookingResponse.setBookings(usersBookingDtos);
		}

		if (!usersBookingResponse.isStatus()) {
			ResponseMessageDto responseMessageDto = new ResponseMessageDto("Failure",
					"Photographer booking details not found", "", new Date(), false);
			return ResponseEntity.status(HttpStatus.OK).body(responseMessageDto);
		}

		return ResponseEntity.ok(usersBookingResponse);
	}
	
	// -------------------------------------------------------------------------
	// Back-end API to terms & Condition , about-us
	// -------------------------------------------------------------------------
	
	@RequestMapping(value = "/terms-about-us", method = RequestMethod.GET)
    public TermsAboutUs getTermsAboutUs() {
        TermsAboutUs termsAboutUs = new TermsAboutUs();
        termsAboutUs.setTerms(termsAboutUs.getTerms());
        termsAboutUs.setAboutUs(termsAboutUs.getAboutUs());
        return termsAboutUs;
    }

}
