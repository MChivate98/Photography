package com.example.PhotographyApplication.Exception;


@SuppressWarnings("serial")
public class DuplicatePhoneNumberException extends RuntimeException{
	public DuplicatePhoneNumberException(String message) {
        super(message);
    }
}