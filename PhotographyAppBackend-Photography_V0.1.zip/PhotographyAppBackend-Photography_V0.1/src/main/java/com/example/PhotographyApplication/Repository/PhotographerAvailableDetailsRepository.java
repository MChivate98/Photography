package com.example.PhotographyApplication.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.PhotographyApplication.Model.PhotographerAvailableDetails;

@Repository
public interface PhotographerAvailableDetailsRepository extends JpaRepository<PhotographerAvailableDetails, Long> {

}
