package com.example.PhotographyApplication.Dto;

import java.util.List;

public class UsersBookingResponse {

	private boolean status;
	private List<UsersBookingDto> bookings;

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public List<UsersBookingDto> getBookings() {
		return bookings;
	}

	public void setBookings(List<UsersBookingDto> bookings) {
		this.bookings = bookings;
	}

}
