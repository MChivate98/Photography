package com.example.PhotographyApplication.Service;

import java.util.List;

import com.example.PhotographyApplication.Model.Users;

public interface UsersService {

	void saveUsers(Users users);

	Users findByEmail(String email);

	List<Users> getAllUsers();

	Users getUsersById(Long userId);

	void deleteUsersById(Long userId);

	Users updateUser(Long userId, Users updatedUser);

	boolean isPhoneNumberTakenByOtherUser(String phoneNumber, Long userIdToExclude);
}
