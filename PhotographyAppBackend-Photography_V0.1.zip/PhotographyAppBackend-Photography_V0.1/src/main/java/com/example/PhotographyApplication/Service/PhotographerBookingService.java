package com.example.PhotographyApplication.Service;

import java.util.List;

import com.example.PhotographyApplication.Dto.PhotographerBookingDto;
import com.example.PhotographyApplication.Model.PhotographerBooking;

public interface PhotographerBookingService {

	PhotographerBooking savePhotographerBooking(PhotographerBooking photographerBooking);
	
	List<PhotographerBooking> getAllPhotographerBooking();

	PhotographerBooking getPhotographerById(Long photographerId);
	
	List<PhotographerBooking> getPhotographerByPhotographerId(Long photographerId);
}
