package com.example.PhotographyApplication.Dto;

import java.util.Date;

public class UsersBookingDto {

	private Long usersBookingId;
	private Date usersBookingRegDate;
	private String startTime;
	private String endTime;
	private Long pricePerHour;
	private String duration;
	private String userName;
	private String startSessionOtp;
	private String endSessioOtp;
	private String address;
	private String status;
	private Long userId;

	public Long getUsersBookingId() {
		return usersBookingId;
	}

	public void setUsersBookingId(Long usersBookingId) {
		this.usersBookingId = usersBookingId;
	}

	public Date getUsersBookingRegDate() {
		return usersBookingRegDate;
	}

	public void setUsersBookingRegDate(Date usersBookingRegDate) {
		this.usersBookingRegDate = usersBookingRegDate;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public Long getPricePerHour() {
		return pricePerHour;
	}

	public void setPricePerHour(Long pricePerHour) {
		this.pricePerHour = pricePerHour;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getStartSessionOtp() {
		return startSessionOtp;
	}

	public void setStartSessionOtp(String startSessionOtp) {
		this.startSessionOtp = startSessionOtp;
	}

	public String getEndSessioOtp() {
		return endSessioOtp;
	}

	public void setEndSessioOtp(String endSessioOtp) {
		this.endSessioOtp = endSessioOtp;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}
}
