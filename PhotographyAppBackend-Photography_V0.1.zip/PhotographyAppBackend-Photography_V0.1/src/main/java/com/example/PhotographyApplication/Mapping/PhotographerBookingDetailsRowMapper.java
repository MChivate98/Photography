package com.example.PhotographyApplication.Mapping;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.example.PhotographyApplication.Model.Photographer;
import com.example.PhotographyApplication.Model.PhotographerBooking;

public class PhotographerBookingDetailsRowMapper implements RowMapper<PhotographerBooking> {

	@Override
	public PhotographerBooking mapRow(ResultSet rs, int rowNum) throws SQLException {
		PhotographerBooking photographerBooking = new PhotographerBooking();
		photographerBooking.setPhotographerBookingId(rs.getLong("photographer_booking_id"));
		photographerBooking.setUserName(rs.getString("user_name"));
		photographerBooking.setAddress(rs.getString("address"));
		photographerBooking.setDuration(rs.getString("duration"));
		photographerBooking.setEndSessioOtp(rs.getString("end_session_otp"));
		photographerBooking.setEndTime(rs.getString("end_time"));
		photographerBooking.setPhotographerBookingRegDate(rs.getDate("photographer_reg_date"));
		photographerBooking.setPricePerHour(rs.getLong("price_per_hour"));
		photographerBooking.setStartSessionOtp(rs.getString("start_session_otp"));
		photographerBooking.setStartTime(rs.getString("start_time"));
		photographerBooking.setStatus(rs.getString("status"));

		Photographer photographer = new Photographer();
		photographer.setPhotographerId(rs.getLong("photographer_id"));
		photographerBooking.setPhotographer(photographer);
		return photographerBooking;

	}
}
