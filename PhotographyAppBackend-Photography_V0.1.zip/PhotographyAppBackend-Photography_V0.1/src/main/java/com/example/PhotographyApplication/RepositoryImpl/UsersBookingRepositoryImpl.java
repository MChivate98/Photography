package com.example.PhotographyApplication.RepositoryImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.example.PhotographyApplication.Mapping.PhotographerBookingDetailsRowMapper;
import com.example.PhotographyApplication.Mapping.UsersBookingDetailsRowMapper;
import com.example.PhotographyApplication.Model.PhotographerBooking;
import com.example.PhotographyApplication.Model.UsersBooking;
import com.example.PhotographyApplication.Repository.PhotographerBookingRepository;
import com.example.PhotographyApplication.Repository.UsersBookingRepository;
import com.example.PhotographyApplication.Service.UsersBookingService;

@Service
public class UsersBookingRepositoryImpl implements UsersBookingService {

	@Autowired
	private UsersBookingRepository usersBookingRepository;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public UsersBooking saveUsersBooking(UsersBooking usersBooking) {
		return usersBookingRepository.save(usersBooking);
	}

	@Override
	public List<UsersBooking> getAllUsersBooking() {
		return usersBookingRepository.findAll();
	}

	@Override
	public UsersBooking getUsersBookingById(Long usersBookingId) {
		try {
			return usersBookingRepository.findById(usersBookingId).orElse(null);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<UsersBooking> getUsersByUserId(Long userId) {
		String query = "SELECT * FROM users_booking WHERE user_id = ?";
		List<UsersBooking> usersBookings = jdbcTemplate.query(query, new Object[] { userId },
				new UsersBookingDetailsRowMapper());
		return usersBookings;
	}

}
