package com.example.PhotographyApplication.RepositoryImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.PhotographyApplication.Model.PhotographerAvailableDetails;
import com.example.PhotographyApplication.Repository.PhotographerAvailableDetailsRepository;
import com.example.PhotographyApplication.Service.PhotographerAvailableDetailsService;

@Service
public class PhotographerAvailableDetailsRepositoryImpl implements PhotographerAvailableDetailsService{

	@Autowired
	private PhotographerAvailableDetailsRepository photographerAvailableDetailsRepository;

//    @Autowired
//    public PhotographerAvailableDetailsRepositoryImpl(PhotographerAvailableDetailsRepository photographerAvailableDetailsRepository) {
//        this.photographerAvailableDetailsRepository = photographerAvailableDetailsRepository;
//    }
    
	@Override
	public void save(PhotographerAvailableDetails photographerAvailableDetails) {
		this.photographerAvailableDetailsRepository.save(photographerAvailableDetails);
	}

	@Override
	public List<PhotographerAvailableDetails> getAllPhotographerAvailableDetails() {
		return photographerAvailableDetailsRepository.findAll();
	}

	@Override
	public PhotographerAvailableDetails getPhotographerAvailableDetailsById(Long photographerAvailableId) {
		try {
			return photographerAvailableDetailsRepository.findById(photographerAvailableId).orElse(null);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public PhotographerAvailableDetails updatePhotographerAvailableDetails(Long photographerAvailableId,
			PhotographerAvailableDetails updatedPhotographer) {
		PhotographerAvailableDetails existingPhotographer = photographerAvailableDetailsRepository.findById(photographerAvailableId).orElse(null);

        if (existingPhotographer != null) {
            // Update the properties of the existing photographer available time
            existingPhotographer.setStartTime(updatedPhotographer.getStartTime());
            existingPhotographer.setEndTime(updatedPhotographer.getEndTime());
            existingPhotographer.setPricePerHour(updatedPhotographer.getPricePerHour());
            existingPhotographer.setWorkingDays(updatedPhotographer.getWorkingDays());
            existingPhotographer.setState(updatedPhotographer.getState());
            existingPhotographer.setCity(updatedPhotographer.getCity());
            existingPhotographer.setAddress(updatedPhotographer.getAddress());
            existingPhotographer.setLocationLatitude(updatedPhotographer.getLocationLatitude());
            existingPhotographer.setLocationLongitude(updatedPhotographer.getLocationLongitude());

            // Save the updated photographer
            return photographerAvailableDetailsRepository.save(existingPhotographer);
        }

        // Return null if the photographer with the given ID is not found
        return null;
    }


}
