package com.example.PhotographyApplication.Config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

//public class SecurityConfig extends WebSecurityConfigurerAdapter{
	
	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

		http.authorizeRequests()
				.antMatchers("/login", "/css/**", "/js/**", "/api/users/**", "/api/photographer/**")
				.permitAll()
				.antMatchers("/**").hasAnyRole("USER", "ADMIN")
				.anyRequest().authenticated()
				.and()
				.formLogin().loginPage("/login").defaultSuccessUrl("/dashboard").permitAll()
				.and()
				.logout().logoutUrl("/signout").permitAll();

		http.csrf().disable();

		return http.build();
	}


//    @Override
//    protected void configure(HttpSecurity http) throws Exception {
//        http
//            .authorizeRequests()
//                .antMatchers("/login", "/css/**", "/js/**","/api/users/**", "/api/photographer/**").permitAll() 
//                .anyRequest().authenticated()
//                .and()
//            .formLogin()
//                .loginPage("/login")
//                .defaultSuccessUrl("/dashboard") // Redirect after successful login
//                .permitAll()
//                .and()
//            .logout()
//                .permitAll();
//    }

	

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public UserDetailsService userDetailsService() {
		UserDetails user = User.builder().username("admin@gmail.com") // Change this to your actual admin username
				.password(passwordEncoder().encode("12345678")) // Change this to your actual admin password
				.roles("ADMIN").build();

		return new InMemoryUserDetailsManager(user);
	}
}
