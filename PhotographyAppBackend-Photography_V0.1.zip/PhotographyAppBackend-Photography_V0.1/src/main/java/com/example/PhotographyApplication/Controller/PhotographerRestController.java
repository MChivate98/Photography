package com.example.PhotographyApplication.Controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.PhotographyApplication.Dto.LoginDteailsMessageDto;
import com.example.PhotographyApplication.Dto.PhotographerBookingDto;
import com.example.PhotographyApplication.Dto.PhotographerBookingResponse;
import com.example.PhotographyApplication.Dto.PhotographerDto;
import com.example.PhotographyApplication.Dto.ResponseMessageDto;
import com.example.PhotographyApplication.Model.Photographer;
import com.example.PhotographyApplication.Model.PhotographerAvailableDetails;
import com.example.PhotographyApplication.Model.PhotographerBooking;
import com.example.PhotographyApplication.Repository.PhotographerRepository;
import com.example.PhotographyApplication.RepositoryImpl.PhotographerOtpService;
import com.example.PhotographyApplication.RepositoryImpl.PhotographerRepositoryImpl;
import com.example.PhotographyApplication.Service.PhotographerAvailableDetailsService;
import com.example.PhotographyApplication.Service.PhotographerBookingService;
import com.example.PhotographyApplication.Service.PhotographerService;

@RestController
@RequestMapping("/api/photographer")
public class PhotographerRestController {

	@Autowired
	private PhotographerService photographerService;

	@Autowired
	private PhotographerRepositoryImpl photographerRepositoryImpl;

	@Autowired
	private PhotographerRepository photographerRepository;

	@Autowired
	private PhotographerOtpService otpService;

	@Autowired
	private PhotographerAvailableDetailsService photographerAvailableDetailsService;

	@Autowired
	private PhotographerBookingService photographerBookingService;

	// -------------------------------------------------------------------------
	// Back-end APT to photographer
	// -------------------------------------------------------------------------

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ResponseEntity<LoginDteailsMessageDto> registerPhotographer(@RequestBody Photographer photographer) {
		LoginDteailsMessageDto responseMessageDto;

		try {
			// Check if a photographer with the same phone number or email already exists
			boolean phoneNumberExists = photographerRepositoryImpl.doesPhoneNumberExist(photographer.getPhoneNumber());
			boolean emailExists = photographerRepositoryImpl.doesEmailExist(photographer.getEmail());

			if (phoneNumberExists || emailExists) {
				responseMessageDto = new LoginDteailsMessageDto("Failed", // Status
						"Phone number or email already exists.", // Message
						null, null, "Duplicate phone number or email", // Error message
						new Date(), false);
				return new ResponseEntity<>(responseMessageDto, HttpStatus.OK);
			}

			photographer.setPhotographerRegDateTime(LocalDate.now());
			photographerService.save(photographer);

			responseMessageDto = new LoginDteailsMessageDto("Success", // Status
					"Photographer successfully registered!", // Message
					null, photographer.getPhotographerId(), null, // Error (set to null for success)
					new Date(), true);

			return new ResponseEntity<>(responseMessageDto, HttpStatus.OK);
		} catch (DataIntegrityViolationException ex) {
			responseMessageDto = new LoginDteailsMessageDto("Failed", // Status
					"An error occurred during registration.", // Message
					null, null, ex.getMessage(), // Error message
					new Date(), false);

			return new ResponseEntity<>(responseMessageDto, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(value = "/detail", method = RequestMethod.POST)
	public ResponseEntity<?> getPhotographerViewRecords(@RequestBody Map<String, Long> request) {
		Long photographerId = request.get("photographerId");

		Photographer photographer = photographerService.getPhotographerById(photographerId);

		if (photographer != null) {
			// Convert Photographer to PhotographerDto
			PhotographerDto photographerDto = convertToDto(photographer);
			// Photographer found, return details
			return ResponseEntity.status(HttpStatus.OK).body(photographerDto);
		} else {
			// Photographer not found, return an error message
			ResponseMessageDto responseMessageDto = new ResponseMessageDto("Failure", "Photographer Details Not Found",
					"", new Date(), false);
			return ResponseEntity.status(HttpStatus.OK).body(responseMessageDto);
		}
	}

	private PhotographerDto convertToDto(Photographer photographer) {
		PhotographerDto photographerDto = new PhotographerDto();
		photographerDto.setPhotographerId(photographer.getPhotographerId());
		photographerDto.setPhotographerRegDateTime(photographer.getPhotographerRegDateTime());
		photographerDto.setUserName(photographer.getUserName());
		photographerDto.setEmail(photographer.getEmail());
		photographerDto.setPhoneNumber(photographer.getPhoneNumber());

		return photographerDto;
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public ResponseEntity<ResponseMessageDto> updatePhotographer(@RequestBody Photographer updatedPhotographer) {

		Long photographerId = updatedPhotographer.getPhotographerId();
		String phoneNumber = updatedPhotographer.getPhoneNumber();

		// Check if a user with the given phone number already exists
		if (photographerService.isPhoneNumberTakenByOtherPhotographer(phoneNumber, photographerId)) {
			ResponseMessageDto numberExistsMessage = new ResponseMessageDto();
			numberExistsMessage.setStatus("Failed");
			numberExistsMessage.setMessage("Phone number already exists");
			numberExistsMessage.setTimestamp(new Date());
			numberExistsMessage.setVerified(false);

			return new ResponseEntity<>(numberExistsMessage, HttpStatus.OK);
		}

		Photographer updatedEntity = photographerService.updatePhotographer(photographerId, updatedPhotographer);

		if (updatedEntity != null) {
			// Successful update
			ResponseMessageDto successMessage = new ResponseMessageDto();
			successMessage.setStatus("Success");
			successMessage.setMessage("Photographer updated successfully");
			successMessage.setTimestamp(new Date());
			successMessage.setVerified(true);

			return new ResponseEntity<>(successMessage, HttpStatus.OK);
		} else {
			// Photographer with the given ID not found
			ResponseMessageDto notFoundMessage = new ResponseMessageDto();
			notFoundMessage.setStatus("Failed");
			notFoundMessage.setMessage("Photographer not found with ID: " + photographerId);
			notFoundMessage.setTimestamp(new Date());
			notFoundMessage.setVerified(false);

			return new ResponseEntity<>(notFoundMessage, HttpStatus.OK);
		}
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseEntity<LoginDteailsMessageDto> login(@RequestBody Photographer loginRequest) {

		String email = loginRequest.getEmail();
		String password = loginRequest.getPassword();
		Photographer photographer = photographerRepository.findByEmail(email);

		if (photographer == null || !photographer.getPassword().equals(password)) {
			// Authentication failed
			return new ResponseEntity<>(
					new LoginDteailsMessageDto("Failed", "Invalid email/password", null, null, null, new Date(), false),
					HttpStatus.OK);
		}

		// Authentication succeeded
		// Generate JWT token or create a session for the user
		// Return a success response
		return new ResponseEntity<>(new LoginDteailsMessageDto("Success", "Login successful", null,
				photographer.getPhotographerId(), null, new Date(), true), HttpStatus.OK);
	}

	@RequestMapping(value = "/send-otp", method = RequestMethod.POST)
	public ResponseEntity<ResponseMessageDto> sendOtp(@RequestBody Photographer loginRequest) {

		String phoneNumber = loginRequest.getPhoneNumber();
		Photographer photographer = photographerRepository.findByPhoneNumber(phoneNumber);

		if (photographer == null) {
			// If the phone number exists, send the OTP
			otpService.sendOtp(phoneNumber);
			// Return a success response
			ResponseMessageDto response = new ResponseMessageDto("Success", "OTP sent successfully", null, new Date(),
					true);
			return ResponseEntity.ok(response);
		} else {
			// If the phone number does not exist, return an error response
			ResponseMessageDto response = new ResponseMessageDto("Failed", "Phone number not found.", null, new Date(),
					false);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}
	}

//	@RequestMapping(value = "/verify-otp", method = RequestMethod.POST)
//	public ResponseEntity<LoginDteailsMessageDto> verifyOtp(@RequestBody Photographer loginRequest) {
//		String phoneNumber = loginRequest.getPhoneNumber();
//		String otpVerificationCode = loginRequest.getOtpVerificationCode();
//
//		// Verify the OTP
//		boolean isOtpVerified = otpService.verifyOtp(phoneNumber, otpVerificationCode);
//		Photographer photographer = photographerRepository.findByPhoneNumber(phoneNumber);
//
//		if (isOtpVerified) {
//			// If the OTP is verified successfully, return a success response
//			LoginDteailsMessageDto response = new LoginDteailsMessageDto("Success", "OTP verified successfully", null,
//					photographer.getPhotographerId(), null, new Date(), true);
//			return ResponseEntity.ok(response);
//		} else {
//			// If the OTP is not verified, return an error response
//			LoginDteailsMessageDto response = new LoginDteailsMessageDto("Failed", "OTP is not matching", null, null,
//					null, new Date(), false);
//			return ResponseEntity.status(HttpStatus.OK).body(response);
//		}
//	}

	@RequestMapping(value = "/verify-otp", method = RequestMethod.POST)
	public ResponseEntity<LoginDteailsMessageDto> verifyOtp(@RequestBody Photographer loginRequest) {
		String phoneNumber = loginRequest.getPhoneNumber();
		String otpVerificationCode = loginRequest.getOtpVerificationCode(); // Assuming this is the field where user
																			// provides OTP

		Photographer photographer = photographerRepository.findByPhoneNumber(phoneNumber);
		// Assuming the fixed value you want to compare with is "1234"
		String fixedOtpValue = "1234";

		// Check if the provided OTP matches the fixed value
		if (fixedOtpValue.equals(otpVerificationCode)) {
			LoginDteailsMessageDto response = new LoginDteailsMessageDto("Success", "OTP verified successfully", null,
					photographer.getPhotographerId(), null, new Date(), true);
			return ResponseEntity.ok(response);
		} else {
			// If the OTP is not verified, return an error response
			LoginDteailsMessageDto response = new LoginDteailsMessageDto("Failed", "OTP is not matching", null, null,
					null, new Date(), false);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}
	}

	@RequestMapping(value = "/check-validate", method = RequestMethod.POST)
	public ResponseEntity<ResponseMessageDto> validatePhotographer(@RequestBody Photographer photographer) {
		ResponseMessageDto responseMessageDto = new ResponseMessageDto();

		boolean phoneNumberExists = photographerRepositoryImpl.doesPhoneNumberExist(photographer.getPhoneNumber());
		boolean emailExists = photographerRepositoryImpl.doesEmailExist(photographer.getEmail());

		if (phoneNumberExists || emailExists) {
			responseMessageDto.setStatus("Failed");
			responseMessageDto.setMessage("Phone number or email already exists");
			responseMessageDto.setError("Validation failed");
			responseMessageDto.setVerified(false);
		} else {
			responseMessageDto.setStatus("Success");
			responseMessageDto.setMessage("Validation succeeded");
			responseMessageDto.setError(null);
			responseMessageDto.setVerified(true);
		}

		return ResponseEntity.ok(responseMessageDto);
	}

	// -------------------------------------------------------------------------
	// Back-end API to photographer Available Details
	// -------------------------------------------------------------------------

	@RequestMapping(value = "/add-available-time", method = RequestMethod.POST)
	public ResponseEntity<LoginDteailsMessageDto> addPhotographerAvailableDatails(
			@RequestBody PhotographerAvailableDetails photographerAvailableDetails) {
		LoginDteailsMessageDto responseMessageDto;

		try {

			photographerAvailableDetails.setPhotographerAvailableRegDateTime(LocalDate.now());
			photographerAvailableDetailsService.save(photographerAvailableDetails);

			responseMessageDto = new LoginDteailsMessageDto("Success", // Status
					"Photographer Available Details add successfully", // Message
					null, photographerAvailableDetails.getPhotographerAvailableId(), null, // Error (set to null for
																							// success)
					new Date(), true);

			return new ResponseEntity<>(responseMessageDto, HttpStatus.OK);
		} catch (DataIntegrityViolationException ex) {
			responseMessageDto = new LoginDteailsMessageDto("Failed", // Status
					"Photographer Available Details is not add successfully .", // Message
					null, null, ex.getLocalizedMessage(), // Error message
					new Date(), false);
			return new ResponseEntity<>(responseMessageDto, HttpStatus.OK);
		}
	}

	@RequestMapping(value = "/update-available-time", method = RequestMethod.POST)
	public ResponseEntity<ResponseMessageDto> updatePhotographerAvailableDatails(
			@RequestBody PhotographerAvailableDetails updatedPhotographer) {

		Long photographerAvailableId = updatedPhotographer.getPhotographerAvailableId();

		PhotographerAvailableDetails updatedEntity = photographerAvailableDetailsService
				.updatePhotographerAvailableDetails(photographerAvailableId, updatedPhotographer);

		if (updatedEntity != null) {
			// Successful update
			ResponseMessageDto successMessage = new ResponseMessageDto();
			successMessage.setStatus("Success");
			successMessage.setMessage("Photographer available time updated successfully");
			successMessage.setTimestamp(new Date());
			successMessage.setVerified(true);

			return new ResponseEntity<>(successMessage, HttpStatus.OK);
		} else {
			// Photographer with the given ID not found
			ResponseMessageDto notFoundMessage = new ResponseMessageDto();
			notFoundMessage.setStatus("Failed");
			notFoundMessage.setMessage("Photographer available time not found with ID: " + photographerAvailableId);
			notFoundMessage.setTimestamp(new Date());
			notFoundMessage.setVerified(false);

			return new ResponseEntity<>(notFoundMessage, HttpStatus.OK);
		}
	}

	@RequestMapping(value = "/available-time-detail", method = RequestMethod.POST)
	public ResponseEntity<?> getPhotographerAvailableDatailsViewRecords(@RequestBody Map<String, Long> request) {
		Long photographerAvailableId = request.get("photographerAvailableId");

		PhotographerAvailableDetails photographerAvailableDetails = photographerAvailableDetailsService
				.getPhotographerAvailableDetailsById(photographerAvailableId);

		if (photographerAvailableDetails != null) {
			// Convert Photographer to PhotographerDto
			PhotographerAvailableDetails photographerDto = convertToDto(photographerAvailableDetails);
			// Photographer found, return details
			return ResponseEntity.status(HttpStatus.OK).body(photographerDto);
		} else {
			// Photographer not found, return an error message
			ResponseMessageDto responseMessageDto = new ResponseMessageDto("Failure", "Photographer Details Not Found",
					"", new Date(), false);
			return ResponseEntity.status(HttpStatus.OK).body(responseMessageDto);
		}
	}

	private PhotographerAvailableDetails convertToDto(PhotographerAvailableDetails photographer) {
		PhotographerAvailableDetails photographerDto = new PhotographerAvailableDetails();
		photographerDto.setPhotographerAvailableId(photographer.getPhotographerAvailableId());
		photographerDto.setPhotographerAvailableRegDateTime(photographer.getPhotographerAvailableRegDateTime());
		photographerDto.setStartTime(photographer.getStartTime());
		photographerDto.setEndTime(photographer.getEndTime());
		photographerDto.setPricePerHour(photographer.getPricePerHour());
		photographerDto.setWorkingDays(photographer.getWorkingDays());
		photographerDto.setState(photographer.getState());
		photographerDto.setCity(photographer.getCity());
		photographerDto.setAddress(photographer.getAddress());
		photographerDto.setLocationLatitude(photographer.getLocationLatitude());
		photographerDto.setLocationLongitude(photographer.getLocationLongitude());

		return photographerDto;
	}

	// -------------------------------------------------------------------------
	// Back-end API to photographer Booking Details
	// -------------------------------------------------------------------------

	@RequestMapping(value = "/save-booking", method = RequestMethod.POST)
	public ResponseEntity<ResponseMessageDto> addPhotographerBooking(@RequestBody PhotographerBookingDto request) {
		ResponseMessageDto responseMessageDto;

		try {

			Photographer photographer1 = photographerService.getPhotographerById(request.getPhotographerId());
			PhotographerBooking photographer = new PhotographerBooking();
			photographer.setPhotographerBookingRegDate(new Date());
			photographer.setUserName(request.getUserName());
			photographer.setAddress(request.getAddress());
			photographer.setStartTime(request.getStartTime());
			photographer.setEndTime(request.getEndTime());
			photographer.setPricePerHour(request.getPricePerHour());
			photographer.setDuration(request.getDuration());
			photographer.setEndSessioOtp(request.getEndSessioOtp());
			photographer.setStartSessionOtp(request.getStartSessionOtp());
			photographer.setAddress(request.getAddress());
			photographer.setStatus(request.getStatus());
			photographer.setPhotographer(photographer1);

			photographerBookingService.savePhotographerBooking(photographer);

			responseMessageDto = new ResponseMessageDto("Success", "Photographer Booking add successfully", "",
					new Date(), true);

			return new ResponseEntity<>(responseMessageDto, HttpStatus.OK);
		} catch (DataIntegrityViolationException ex) {
			responseMessageDto = new ResponseMessageDto("Failure", "Photographer Booking is not add successfully", "",
					new Date(), false);
			return new ResponseEntity<>(responseMessageDto, HttpStatus.OK);
		}
	}


	@RequestMapping(value = "/booking-details", method = RequestMethod.POST)
	public ResponseEntity<?> getPhotographerBookingDatailsViewRecords(@RequestBody Map<String, Object> request) {

		Number photographerIdNumber = (Number) request.get("photographerId");
		Long photographerId = photographerIdNumber.longValue(); // Converts to Long

		String bookingType = (String) request.get("bookingType");

		List<PhotographerBooking> photographerBookings = photographerBookingService
				.getPhotographerByPhotographerId(photographerId);

		PhotographerBookingResponse photographerBookingResponse = new PhotographerBookingResponse();
		List<PhotographerBookingDto> photographerBookingDtos = new ArrayList<>();

		for (PhotographerBooking photographerBooking : photographerBookings) {
			if (photographerBooking.getPhotographer().getPhotographerId().equals(photographerId)) {
				PhotographerBookingDto photographerBookingDto = new PhotographerBookingDto();
				photographerBookingDto.setPhotographerBookingId(photographerBooking.getPhotographerBookingId());
				photographerBookingDto.setPhotographerId(photographerId);
				photographerBookingDto.setPhotographerBookingRegDate(new Date());
				photographerBookingDto.setUserName(photographerBooking.getUserName());
				photographerBookingDto.setAddress(photographerBooking.getAddress());
				photographerBookingDto.setStartTime(photographerBooking.getStartTime());
				photographerBookingDto.setEndTime(photographerBooking.getEndTime());
				photographerBookingDto.setPricePerHour(photographerBooking.getPricePerHour());
				photographerBookingDto.setDuration(photographerBooking.getDuration());
				photographerBookingDto.setEndSessioOtp(photographerBooking.getEndSessioOtp());
				photographerBookingDto.setStartSessionOtp(photographerBooking.getStartSessionOtp());
				photographerBookingDto.setStatus(photographerBooking.getStatus());

				// Check booking type and status
				if (bookingType.equalsIgnoreCase("past") && (photographerBooking.getStatus().equalsIgnoreCase("completed")
						||photographerBooking.getStatus().equalsIgnoreCase("cancelled"))) {
					photographerBookingDtos.add(photographerBookingDto);
				} else if (bookingType.equalsIgnoreCase("ongoing")
						&& (photographerBooking.getStatus().equalsIgnoreCase("accepted")
								|| photographerBooking.getStatus().equalsIgnoreCase("ongoing"))) {
					photographerBookingDtos.add(photographerBookingDto);
				}
			}
		}

		if (photographerBookingDtos.isEmpty()) {
			photographerBookingResponse.setStatus(false);
		} else {
			photographerBookingResponse.setStatus(true);
			photographerBookingResponse.setBookings(photographerBookingDtos);
		}

		if (!photographerBookingResponse.isStatus()) {
			ResponseMessageDto responseMessageDto = new ResponseMessageDto("Failure",
					"Photographer booking details not found", "", new Date(), false);
			return ResponseEntity.status(HttpStatus.OK).body(responseMessageDto);
		}

		return ResponseEntity.ok(photographerBookingResponse);
	}


}
