package com.example.PhotographyApplication.Dto;

import java.util.List;

public class PhotographerBookingResponse {

	private boolean status;
	private List<PhotographerBookingDto> bookings;

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public List<PhotographerBookingDto> getBookings() {
		return bookings;
	}

	public void setBookings(List<PhotographerBookingDto> bookings) {
		this.bookings = bookings;
	}

}
