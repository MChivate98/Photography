package com.example.PhotographyApplication.Dto;

import java.util.Date;

public class LoginDteailsMessageDto {

	private String status;
	private String message;
	private Long userId;
	private Long photographerId;
	private String error;
	private Date timestamp;
	private boolean verified;

	public LoginDteailsMessageDto() {
		super();
	}

	public LoginDteailsMessageDto(String status, String message,Long userId,Long photographerId, String error, Date timestamp,boolean verified) {
		super();
		this.status = status;
		this.message = message;
		this.userId = userId;
		this.photographerId = photographerId;
		this.error = error;
		this.timestamp = timestamp;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public boolean isVerified() {
		return verified;
	}

	public void setVerified(boolean verified) {
		this.verified = verified;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getPhotographerId() {
		return photographerId;
	}

	public void setPhotographerId(Long photographerId) {
		this.photographerId = photographerId;
	}

}
