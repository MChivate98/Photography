package com.example.PhotographyApplication.Dto;

public class UserRequestDto {

	private String phoneNumber;
	private String userType;
//	private boolean userType;

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

}
