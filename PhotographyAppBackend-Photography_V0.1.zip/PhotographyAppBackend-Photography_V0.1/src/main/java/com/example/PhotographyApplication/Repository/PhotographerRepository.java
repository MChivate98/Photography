package com.example.PhotographyApplication.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.PhotographyApplication.Model.Photographer;

@Repository
public interface PhotographerRepository extends JpaRepository<Photographer, Long> {

	Photographer findByPhoneNumber(String phoneNumber);

	Photographer findByEmail(String email);

	boolean existsByPhoneNumber(String phoneNumber);

	boolean existsByEmail(String email);

	@Query("SELECT COUNT(p) FROM Photographer p WHERE p.phoneNumber = :phoneNumber")
	int countByPhoneNumber(@Param("phoneNumber") String phoneNumber);

	boolean existsByPhoneNumberAndPhotographerIdNot(String phoneNumber, Long photographerIdToExclude);
	
	long count();
}
