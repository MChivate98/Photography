package com.example.PhotographyApplication.Mapping;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.example.PhotographyApplication.Model.Users;
import com.example.PhotographyApplication.Model.UsersBooking;

public class UsersBookingDetailsRowMapper implements RowMapper<UsersBooking> {

	@Override
	public UsersBooking mapRow(ResultSet rs, int rowNum) throws SQLException {
		UsersBooking usersBooking = new UsersBooking();
		usersBooking.setUsersBookingId(rs.getLong("users_booking_id"));
		usersBooking.setUserName(rs.getString("user_name"));
		usersBooking.setAddress(rs.getString("address"));
		usersBooking.setDuration(rs.getString("duration"));
		usersBooking.setEndSessioOtp(rs.getString("end_session_otp"));
		usersBooking.setEndTime(rs.getString("end_time"));
		usersBooking.setUsersBookingRegDate(rs.getDate("users_booking_reg_date"));
		usersBooking.setPricePerHour(rs.getLong("price_per_hour"));
		usersBooking.setStartSessionOtp(rs.getString("start_session_otp"));
		usersBooking.setStartTime(rs.getString("start_time"));
		usersBooking.setStatus(rs.getString("status"));

		Users users = new Users();
		users.setUserId(rs.getLong("user_id"));
		usersBooking.setUsers(users);
		return usersBooking;

	}
}
