package com.example.PhotographyApplication.Model;

public class TermsAboutUs {

	private String aboutUs = "1. Use of the App\r\n"
			+ "By your use of this app, you confirm your acceptance and it would be accepted as would a written agreement with your signature. Your use of this app confirms your agreement to follow these terms and conditions and to be bound by them.\r\n"
			+ "\r\n" + "2. Agreement and the parties\r\n" + "3. Limitations of liability\r\n"
			+ "“Agreement” means the terms and conditions as detailed herein including all schedules, appendices,\r\n"
			+ "annexures, privacy policy, and payment policy and will include the references\r\n" + "\r\n"
			+ "4. Technology limitations \r\n"
			+ "“Agreement” means the terms and conditions as detailed herein including all schedules, appendices,\r\n"
			+ "annexures, privacy policy, and payment policy and will include the references\r\n" + "\r\n"
			+ "5. Agreement and the parties\r\n"
			+ "“Agreement” means the terms and conditions as detailed herein including all schedules, appendices,\r\n"
			+ "annexures, privacy policy, and payment policy and will include the references\r\n" + "\r\n"
			+ "“Agreement” means the terms and conditions as detailed herein including all schedules, appendices,\r\n"
			+ "annexures,\r\n" + "";
	private String terms = "1. Use of the App\r\n"
			+ "By your use of this app, you confirm your acceptance and it would be accepted as would a written agreement with your signature. Your use of this app confirms your agreement to follow these terms and conditions and to be bound by them.\r\n"
			+ "\r\n" + "2. Agreement and the parties\r\n" + "3. Limitations of liability\r\n"
			+ "“Agreement” means the terms and conditions as detailed herein including all schedules, appendices,\r\n"
			+ "annexures, privacy policy, and payment policy and will include the references\r\n" + "\r\n"
			+ "4. Technology limitations \r\n"
			+ "“Agreement” means the terms and conditions as detailed herein including all schedules, appendices,\r\n"
			+ "annexures, privacy policy, and payment policy and will include the references\r\n" + "\r\n"
			+ "5. Agreement and the parties\r\n"
			+ "“Agreement” means the terms and conditions as detailed herein including all schedules, appendices,\r\n"
			+ "annexures, privacy policy, and payment policy and will include the references\r\n" + "\r\n"
			+ "“Agreement” means the terms and conditions as detailed herein including all schedules, appendices,\r\n"
			+ "annexures,\r\n" + "";

	public String getAboutUs() {
		return aboutUs;
	}

	public void setAboutUs(String aboutUs) {
		this.aboutUs = aboutUs;
	}

	public String getTerms() {
		return terms;
	}

	public void setTerms(String terms) {
		this.terms = terms;
	}

}
