package com.example.PhotographyApplication.Service;

import java.util.List;

import com.example.PhotographyApplication.Model.PhotographerAvailableDetails;

public interface PhotographerAvailableDetailsService {

	void save(PhotographerAvailableDetails photographerAvailableDetails);

	List<PhotographerAvailableDetails> getAllPhotographerAvailableDetails();

	PhotographerAvailableDetails getPhotographerAvailableDetailsById(Long photographerAvailableId);

	PhotographerAvailableDetails updatePhotographerAvailableDetails(Long photographerAvailableId, PhotographerAvailableDetails updatedPhotographer);

}
