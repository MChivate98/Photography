package com.example.PhotographyApplication.Service;

import java.util.List;

import com.example.PhotographyApplication.Model.Photographer;


public interface PhotographerService {

	void save(Photographer photographer);
	
	List<Photographer> getAllPhotographers();

	Photographer getPhotographerById(Long photographerId);

	void deletePhotographerById(Long photographerId);

	Photographer updatePhotographer(Long photographerId, Photographer updatedPhotographer);

	boolean isPhoneNumberTakenByOtherPhotographer(String phoneNumber, Long photographerIdToExclude);
}
