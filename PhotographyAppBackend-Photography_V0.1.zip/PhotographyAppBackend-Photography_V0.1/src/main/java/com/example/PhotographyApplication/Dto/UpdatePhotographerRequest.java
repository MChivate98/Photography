package com.example.PhotographyApplication.Dto;

import java.util.Map;

import com.example.PhotographyApplication.Model.Photographer;

public class UpdatePhotographerRequest {
	
	private Photographer updatedPhotographer;
	private Map<String, Long> request;

	public Photographer getUpdatedPhotographer() {
		return updatedPhotographer;
	}

	public void setUpdatedPhotographer(Photographer updatedPhotographer) {
		this.updatedPhotographer = updatedPhotographer;
	}

	public Map<String, Long> getRequest() {
		return request;
	}

	public void setRequest(Map<String, Long> request) {
		this.request = request;
	}

}
