package com.example.PhotographyApplication.RepositoryImpl;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.example.PhotographyApplication.Dto.PhotographerBookingDto;
import com.example.PhotographyApplication.Dto.PhotographerBookingResponse;
import com.example.PhotographyApplication.Mapping.PhotographerBookingDetailsRowMapper;
import com.example.PhotographyApplication.Model.PhotographerBooking;
import com.example.PhotographyApplication.Repository.PhotographerBookingRepository;
import com.example.PhotographyApplication.Service.PhotographerBookingService;

@Service
public class PhotographerBookingRepositoryImpl implements PhotographerBookingService {

	@Autowired
	private PhotographerBookingRepository photographerBookingRepository;	

	@Autowired
    private JdbcTemplate jdbcTemplate;

	@Override
	public PhotographerBooking savePhotographerBooking(PhotographerBooking photographerBooking) {
		return photographerBookingRepository.save(photographerBooking);

	}

    @Override
    public List<PhotographerBooking> getPhotographerByPhotographerId(Long photographerId) {
        String query = "SELECT * FROM photographer_booking WHERE photographer_id = ?";
        List<PhotographerBooking> photographerBookings = jdbcTemplate.query(query, new Object[] {photographerId}, new PhotographerBookingDetailsRowMapper());
        return photographerBookings;
    }

	@Override
	public List<PhotographerBooking> getAllPhotographerBooking() {
		return photographerBookingRepository.findAll();
	}

	@Override
	public PhotographerBooking getPhotographerById(Long photographerId) {
		try {
			return photographerBookingRepository.findById(photographerId).orElse(null);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
