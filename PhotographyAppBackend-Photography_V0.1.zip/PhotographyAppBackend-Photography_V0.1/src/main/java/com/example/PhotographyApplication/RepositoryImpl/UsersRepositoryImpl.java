package com.example.PhotographyApplication.RepositoryImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.PhotographyApplication.Model.Users;
import com.example.PhotographyApplication.Repository.UsersRepository;
import com.example.PhotographyApplication.Service.UsersService;

@Service
public class UsersRepositoryImpl implements UsersService {

	@Autowired
	private UsersRepository usersRepository;

	@Override
	public void saveUsers(Users users) {
		this.usersRepository.save(users);
	}

	@Override
	public Users findByEmail(String email) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Users> getAllUsers() {
		return usersRepository.findAll();
	}

	@Override
	public Users getUsersById(Long userId) {
		try {
			return usersRepository.findById(userId).orElse(null);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	 public Users updateUser(Long userId, Users updatedUser) {
        Users existingUser = usersRepository.findById(userId).orElse(null);

        if (existingUser != null) {
            // Update the properties of the existing user
            existingUser.setUserName(updatedUser.getUserName());
            existingUser.setPhoneNumber(updatedUser.getPhoneNumber());

            // Save the updated user
            return usersRepository.save(existingUser);
        }

        // Return null if the user with the given ID is not found
        return null;
    }


    @Override
    public boolean isPhoneNumberTakenByOtherUser(String phoneNumber, Long userIdToExclude) {
        // Implement the logic to check if the phone number is taken by another user
        return usersRepository.existsByPhoneNumberAndUserIdNot(phoneNumber, userIdToExclude);
    }
    
	@Override
	public void deleteUsersById(Long userId) {
		this.usersRepository.deleteById(userId);
	}

	public boolean doesPhoneNumberExist(String phoneNumber) {
		return usersRepository.existsByPhoneNumber(phoneNumber);
	}

}
