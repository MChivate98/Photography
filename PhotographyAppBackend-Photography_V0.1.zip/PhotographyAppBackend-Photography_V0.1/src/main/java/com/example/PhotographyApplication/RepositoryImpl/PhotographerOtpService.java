package com.example.PhotographyApplication.RepositoryImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.PhotographyApplication.Model.Photographer;
import com.example.PhotographyApplication.Repository.PhotographerRepository;

import java.util.Random;

@Service
public class PhotographerOtpService {

	@Autowired
	private PhotographerRepository photographerRepository;

	// Method to generate a random OTP of length 6
	private String generateOtp() {
//		Random random = new Random();
//		int otp = 100000 + random.nextInt(900000);
//		return String.valueOf(otp);
		
		int otp = 1234;
		return String.valueOf(otp);
	}

	// Method to send OTP to a phone number
	public void sendOtp(String phoneNumber) {
		// You can use a third-party service or library to send the OTP via SMS here.
		// For simplicity, we'll just generate and print the OTP.
		String otp = generateOtp();
		System.out.println("OTP for " + phoneNumber + ": " + otp);

		// Save the OTP in the database
		Photographer photographer = photographerRepository.findByPhoneNumber(phoneNumber);
		if (photographer != null) {
			photographer.setOtpVerificationCode(otp);
			photographerRepository.save(photographer);
		}
	}

	// Method to verify OTP
	public boolean verifyOtp(String phoneNumber, String otp) {
		Photographer photographer = photographerRepository.findByPhoneNumber(phoneNumber);
		return photographer != null && photographer.getOtpVerificationCode().equals(otp);
	}
}
