package com.example.PhotographyApplication.Model;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Range;

@Entity
@Table(name = "photographerAvailable")
public class PhotographerAvailableDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long photographerAvailableId;

	@Column(name = "photographer_reg_date_time")
	private LocalDate photographerAvailableRegDateTime;

	@Column(name = "start_time")
	private String startTime;

	@Column(name = "end_time")
	private String endTime;

	@Column(name = "price_per_hour")
	private Long pricePerHour;

	@Column(name = "working_days")
	private String workingDays;

	@Column(name = "State")
	private String State;

	@Column(name = "city")
	private String city;

	@Column(name = "address")
	private String address;

	@NotNull(message = "Latitude is required")
	@Range(min = -90, max = 90, message = "Latitude must be between {min} and {max}")
	private BigDecimal locationLatitude;

	@NotNull(message = "Longitude is required")
	@Range(min = -180, max = 180, message = "Longitude must be between {min} and {max}")
	private BigDecimal locationLongitude;

	public Long getPhotographerAvailableId() {
		return photographerAvailableId;
	}

	public void setPhotographerAvailableId(Long photographerAvailableId) {
		this.photographerAvailableId = photographerAvailableId;
	}

	public LocalDate getPhotographerAvailableRegDateTime() {
		return photographerAvailableRegDateTime;
	}

	public void setPhotographerAvailableRegDateTime(LocalDate photographerAvailableRegDateTime) {
		this.photographerAvailableRegDateTime = photographerAvailableRegDateTime;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public Long getPricePerHour() {
		return pricePerHour;
	}

	public void setPricePerHour(Long pricePerHour) {
		this.pricePerHour = pricePerHour;
	}

	public String getWorkingDays() {
		return workingDays;
	}

	public void setWorkingDays(String workingDays) {
		this.workingDays = workingDays;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public BigDecimal getLocationLatitude() {
		return locationLatitude;
	}

	public void setLocationLatitude(BigDecimal locationLatitude) {
		this.locationLatitude = locationLatitude;
	}

	public BigDecimal getLocationLongitude() {
		return locationLongitude;
	}

	public void setLocationLongitude(BigDecimal locationLongitude) {
		this.locationLongitude = locationLongitude;
	}

}
