package com.example.PhotographyApplication.RepositoryImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.PhotographyApplication.Model.Photographer;
import com.example.PhotographyApplication.Repository.PhotographerRepository;
import com.example.PhotographyApplication.Service.PhotographerService;

@Service
public class PhotographerRepositoryImpl implements PhotographerService {

	@Autowired
	private PhotographerRepository photographerRepository;

    @Autowired
    public void PhotographerServiceImpl(PhotographerRepository photographerRepository) {
        this.photographerRepository = photographerRepository;
    }
	
	@Override
	public void save(Photographer photographer) {
		this.photographerRepository.save(photographer);
	}

	@Override
	public List<Photographer> getAllPhotographers() {
		return photographerRepository.findAll();
	}

	@Override
	public Photographer getPhotographerById(Long photographerId) {
		try {
			return photographerRepository.findById(photographerId).orElse(null);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	@Override
	public Photographer updatePhotographer(Long photographerId, Photographer updatedPhotographer) {
        Photographer existingPhotographer = photographerRepository.findById(photographerId).orElse(null);

        if (existingPhotographer != null) {
            // Update the properties of the existing photographer
            existingPhotographer.setUserName(updatedPhotographer.getUserName());
            existingPhotographer.setEmail(updatedPhotographer.getEmail());
            existingPhotographer.setPhoneNumber(updatedPhotographer.getPhoneNumber());

            // Save the updated photographer
            return photographerRepository.save(existingPhotographer);
        }

        // Return null if the photographer with the given ID is not found
        return null;
    }

    @Override
    public boolean isPhoneNumberTakenByOtherPhotographer(String phoneNumber, Long photographerIdToExclude) {
        // Implement the logic to check if the phone number is taken by another user
        return photographerRepository.existsByPhoneNumberAndPhotographerIdNot(phoneNumber, photographerIdToExclude);
    }
    
	@Override
	public void deletePhotographerById(Long photographerId) {
		this.photographerRepository.deleteById(photographerId);
	}

	
    public boolean doesPhoneNumberExist(String phoneNumber) {
        return photographerRepository.existsByPhoneNumber(phoneNumber);
    }

    public boolean doesEmailExist(String email) {
        return photographerRepository.existsByEmail(email);
    }
}
