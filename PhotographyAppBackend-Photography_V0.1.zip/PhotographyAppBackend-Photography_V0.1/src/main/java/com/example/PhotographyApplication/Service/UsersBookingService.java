package com.example.PhotographyApplication.Service;

import java.util.List;
import com.example.PhotographyApplication.Model.UsersBooking;

public interface UsersBookingService {

	UsersBooking saveUsersBooking(UsersBooking usersBooking);

	List<UsersBooking> getAllUsersBooking();

	UsersBooking getUsersBookingById(Long usersBookingId);

	List<UsersBooking> getUsersByUserId(Long userId);
}
