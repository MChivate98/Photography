package com.example.PhotographyApplication.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.PhotographyApplication.Model.Photographer;
import com.example.PhotographyApplication.Model.Users;
import com.example.PhotographyApplication.Repository.PhotographerRepository;
import com.example.PhotographyApplication.Repository.UsersRepository;
import com.example.PhotographyApplication.Service.PhotographerService;
import com.example.PhotographyApplication.Service.UsersService;

@Controller
public class UserPhotographerController {

	@Autowired
	private UsersService usersService;

	@Autowired
	private PhotographerService photographerService;

	@Autowired
	private PhotographerRepository photographerRepository;

	@Autowired
	private UsersRepository usersRepository;

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login() {
		return "login";
	}
	
	@RequestMapping(value = "/userdetails", method = RequestMethod.GET)
	public String userdetails(Model model) {
		List<Users> userList;
		userList = usersService.getAllUsers();
		model.addAttribute("userList", userList);

		return "userdetails";
	}

	@RequestMapping(value = "/userdetails/delete/{userId}", method = RequestMethod.GET)
	public String deleteUser(@PathVariable(value = "userId") Long userId) {
		this.usersService.deleteUsersById(userId);
		return "redirect:/userdetails";
	}

	@GetMapping("/photographerdetails")
	public String photographerdetails(Model model) {
		List<Photographer> photographerList;
		photographerList = photographerService.getAllPhotographers();

		model.addAttribute("photographerList", photographerList);
		return "photographerdetails";
	}

	@RequestMapping(value = "/photographerdetails/delete/{photographerId}", method = RequestMethod.GET)
	public String deletePhotographer(@PathVariable(value = "photographerId") Long photographerId) {
		this.photographerService.deletePhotographerById(photographerId);
		return "redirect:/photographerdetails";
	}

	@GetMapping("/dashboard")
	public String dashboard(Model model) {

		long totalUsers = usersRepository.count();
		model.addAttribute("totalUsers", totalUsers);

		long totalPhotographers = photographerRepository.count();
		model.addAttribute("totalPhotographers", totalPhotographers);

		return "dashboard";
	}

}
