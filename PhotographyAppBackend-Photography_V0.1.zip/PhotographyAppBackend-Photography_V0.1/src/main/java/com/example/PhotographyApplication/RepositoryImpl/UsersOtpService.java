package com.example.PhotographyApplication.RepositoryImpl;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.PhotographyApplication.Model.Users;
import com.example.PhotographyApplication.Repository.UsersRepository;

@Service
public class UsersOtpService {

	@Autowired
	private UsersRepository usersRepository;

	// Method to generate a random OTP of length 6
	private String generateOtp() {
//		Random random = new Random();
//		int otp = 100000 + random.nextInt(900000);
//		return String.valueOf(otp);
		
		int otp = 1234;
		return String.valueOf(otp);
		
	}

	// Method to send OTP to a phone number
	public void sendOtp(String phoneNumber) {
		// You can use a third-party service or library to send the OTP via SMS here.
		// For simplicity, we'll just generate and print the OTP.
		String otp = generateOtp();
		System.out.println("OTP for " + phoneNumber + ": " + otp);

		// Save the OTP in the database
		Users users = usersRepository.findByPhoneNumber(phoneNumber);
		if (users != null) {
			users.setUserOtpVerification(otp);
			usersRepository.save(users);
		}
	}

	// Method to verify OTP
	public boolean verifyOtp(String phoneNumber, String otp) {
		Users users = usersRepository.findByPhoneNumber(phoneNumber);
		return users != null && users.getUserOtpVerification().equals(otp);
	}
}
