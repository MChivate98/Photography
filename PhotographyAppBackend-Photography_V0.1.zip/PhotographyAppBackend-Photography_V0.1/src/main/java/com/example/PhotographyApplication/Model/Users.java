package com.example.PhotographyApplication.Model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "users")
public class Users {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long userId;

	@Column(name = "user_reg_date_time")
	private LocalDate userRegDateTime;

	@Column(name = "user_name")
	private String userName;

	@Column(unique = true)
	@NotEmpty
	private String phoneNumber;

	@Column(name = "user_otp_verification")
	private String userOtpVerification;

	@OneToMany(mappedBy = "users", cascade = CascadeType.ALL)
	private List<UsersBooking> usersBookings = new ArrayList<>();

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public LocalDate getUserRegDateTime() {
		return userRegDateTime;
	}

	public void setUserRegDateTime(LocalDate userRegDateTime) {
		this.userRegDateTime = userRegDateTime;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getUserOtpVerification() {
		return userOtpVerification;
	}

	public void setUserOtpVerification(String userOtpVerification) {
		this.userOtpVerification = userOtpVerification;
	}

}
