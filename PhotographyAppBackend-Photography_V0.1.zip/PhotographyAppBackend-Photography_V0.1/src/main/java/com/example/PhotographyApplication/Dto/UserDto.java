package com.example.PhotographyApplication.Dto;

import java.time.LocalDate;

public class UserDto {

	private Long userId;
	private LocalDate userRegDateTime;
	private String userName;
	private String phoneNumber;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public LocalDate getUserRegDateTime() {
		return userRegDateTime;
	}

	public void setUserRegDateTime(LocalDate userRegDateTime) {
		this.userRegDateTime = userRegDateTime;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

}
