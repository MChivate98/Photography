package com.example.PhotographyApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotographyApplicationTests {

	@Test
	void contextLoads() {
	}

}
